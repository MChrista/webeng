package webeng;

import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.BorderFactory;
import javax.swing.JTextArea;

public class Applet extends java.applet.Applet{
	JTextArea text=new JTextArea("hier steht ihr text");
	public Applet(){
		text.setBorder(BorderFactory.createEtchedBorder());
	    text.setPreferredSize(new Dimension(150, 150));
		this.add(text);
	}
/*	public void paint(Graphics g){
		g.drawString("mein applett", 150, 150);
		
	}*/
	
	public String getText(){
		return text.getText();
	}
	
	public void setText(String eingabe){
		this.text.setText(eingabe);
	}
}
